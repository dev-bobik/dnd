import pyglet
from pyglet import gl
import random

window = pyglet.window.Window(fullscreen=True)
width, height = window.get_size()
global faze_hry,score
global player1_s,player2_s
global p1,p2
global led1,led2, led1_x,led1_y,led2_x,led2_y
global safez1,safez2,sefez1_x,sfaez1_y,sefez2_x,sfaez2_y
p1 = (255,255,0)
p2 = (255,255,0)
faze_hry = 0
player1_x = 50
player1_y = 100
player2_x = 1450
player2_y = 100
player3_x = 750
player3_y = 375
score = 0
havlicek1 = 1
havlicek2 = 1
p1_move = 25
p2_move = 25
p3_move = 25
c1_text = None
c2_text = None
led1_x = 0
led1_y = 0
led2_x = 0
led2_y = 0
sefez1_x = 0
sfaez1_y = 0
sefez2_x = 0
sfaez2_y = 0


def uvod():

    uvod_text1= pyglet.text.Label("Welcome to the game: Color matters",
                            font_name= "Times New Roman",
                            font_size=60,
                            color=(40, 179, 255, 250),
                            x = window.width//2, y = window.height//2,
                            anchor_x = "center", anchor_y="center")
    uvod_text2= pyglet.text.Label("Press Enter to continue",
                            font_name= "Times New Roman",
                            font_size= 30,
                            color=(255,255,255,150),
                            x = window.width//2, y = window.height//2 - 200,
                            anchor_x = "center", anchor_y="center")
    o2 = pyglet.resource.image("colour_matters.png")
    uvod_obr = pyglet. sprite.Sprite(o2, width//2 - 100,20)
    uvod_obr.scale = 0.8
    uvod_text1.draw()
    uvod_text2.draw()
   


def lobby():
    gl.glClearColor(0.56, 0.71, 0.68, 1)
    k1 = pyglet.shapes.Rectangle(50,100,200,100,color=(255,255,255,180))
    k2 = pyglet.shapes.Rectangle(50,250,200,100,color=(255,255,255,180))
    k3 = pyglet.shapes.Rectangle(50,400,200,100,color=(255,255,255,180))
    k4 = pyglet.shapes.Rectangle(50,700,100,100,color=(255,255,255,180))
    o2 = pyglet.resource.image("cmo1.webp")
    lobby_obr = pyglet. sprite.Sprite(o2, 620, 0)
    lobby_obr.scale = 0.9
    k1_text = pyglet.text.Label("New game",
                            font_name= "Times New Roman",
                            font_size= 25,
                            color=(0, 0, 0, 255),
                            x = 150, y = 150,
                            anchor_x= "center", anchor_y = "center")
    k2_text = pyglet.text.Label("Choose character",
                            font_name= "Times New Roman",
                            font_size= 20,
                            color=(0, 0, 0, 255),
                            x = 150, y = 300,
                            anchor_x= "center", anchor_y = "center")
    k3_text = pyglet.text.Label("Instructions",
                            font_name= "Times New Roman",
                            font_size= 25,
                            color=(0, 0, 0, 255),
                            x = 150, y = 450,
                            anchor_x= "center", anchor_y = "center")
    k4_text = pyglet.text.Label("Exit",
                            font_name= "Times New Roman",
                            font_size= 25,
                            color=(0, 0, 0, 255),
                            x = 100, y = 750,
                            anchor_x= "center", anchor_y = "center")
    
    window.clear()
    k1.draw()
    k2.draw()
    k3.draw()
    k4.draw()
    lobby_obr.draw()
    k1_text.draw()
    k2_text.draw()
    k3_text.draw()
    k4_text.draw()




def lobby_vyber_miniher():
    gl.glClearColor(0.56, 0.71, 0.68, 1)
    k1 = pyglet.shapes.Rectangle(50,100,200,100,color=(255,255,255,180)) 
    k2 = pyglet.shapes.Rectangle(50,250,200,100,color=(255,255,255,180))
    k3 = pyglet.shapes.Rectangle(50,400,200,100,color=(255,255,255,180))
    k4 = pyglet.shapes.Rectangle(50,700,100,100,color=(255,255,255,180))
    o2 = pyglet.resource.image("cmo1.webp")
    lobby_obr = pyglet. sprite.Sprite(o2, 620, 0)
    lobby_obr.scale = 0.9
    k1_text = pyglet.text.Label("Locked",
                            font_name= "Times New Roman",
                            font_size= 25,
                            color=(0, 0, 0, 255),
                            x = 150, y = 150,
                            anchor_x= "center", anchor_y = "center")
    k2_text = pyglet.text.Label("Kill the red one",
                            font_name= "Times New Roman",
                            font_size= 20,
                            color=(0, 0, 0, 255),
                            x = 150, y = 300,
                            anchor_x= "center", anchor_y = "center")
    k3_text = pyglet.text.Label("Classic",
                            font_name= "Times New Roman",
                            font_size= 25,
                            color=(0, 0, 0, 255),
                            x = 150, y = 450,
                            anchor_x= "center", anchor_y = "center")
    k4_text = pyglet.text.Label("Lobby",
                            font_name= "Times New Roman",
                            font_size= 25,
                            color=(0, 0, 0, 255),
                            x = 100, y = 750,
                            anchor_x= "center", anchor_y = "center")
    
    window.clear()
    k1.draw()
    k2.draw()
    k3.draw()
    k4.draw()
    lobby_obr.draw()
    k1_text.draw()
    k2_text.draw()
    k3_text.draw()
    k4_text.draw()

def vyber():

    window.clear()
    pyglet.shapes.Rectangle(0,0,width/2,height,color=(150,219,148)).draw()
    pyglet.shapes.Rectangle(width/2,0,width/2,height,color=(161,216,219)).draw()
    pyglet.shapes.Rectangle(width/2-150,0,300, 150, color=(255,0,0)).draw()
    pyglet.shapes.Rectangle(95,5,60,60,color=(0,0,0)).draw()
    pyglet.shapes.Rectangle(width-155,5,60,60,color=(0,0,0)).draw()
    pyglet.shapes.Rectangle(100,10,50,50,color=p1).draw()
    pyglet.shapes.Rectangle(width-150,10,50,50,color=p2).draw()
    pyglet.shapes.Rectangle(765,150,6,height-300,color=(0,0,0)).draw()
    
    pyglet.text.Label("Back to lobby",
                font_name= "Times New Roman",
                font_size= 25,
                color=(0, 0, 0, 255),
                x = 100, y = height-50,
                anchor_x= "center", anchor_y = "center").draw()
    vyber_text1 = pyglet.text.Label("Choose your color",
                            font_name= "Times New Roman",
                            font_size= 50,
                            color=(0, 0, 0, 255),
                            x = width//2, y = height- 100,
                            anchor_x= "center", anchor_y = "center").draw()   
    vyber_text2 = pyglet.text.Label("Player 1",
                            font_name= "Times New Roman",
                            font_size= 40,
                            color=(0, 0, 0, 255),
                            x = width//4 - 75, y = 40,
                            anchor_x= "center", anchor_y = "center").draw()
    vyber_text3 = pyglet.text.Label("Player 2",
                            font_name= "Times New Roman",
                            font_size= 40,
                            color=(0, 0, 0, 255),
                            x = width//4 * 3 + 75, y = 40,
                            anchor_x= "center", anchor_y = "center").draw()
    vyber_text4 = pyglet.text.Label("Player 3",
                            font_name= "Times New Roman",
                            font_size= 40,
                            color=(0, 0, 0, 255),
                            x = width//2, y = 75,
                            anchor_x= "center", anchor_y = "center").draw()
    zlucak_okraj = pyglet.shapes.Rectangle(33,495,135,135,color=(0,0,0)).draw ()
    player1_obj_okraj = pyglet.shapes.Rectangle(213,495,135,135,color=(0,0,0)).draw()
    player2_obj_okraj = pyglet.shapes.Rectangle(393,495,135,135,color=(0,0,0)).draw()
    fiala_okraj = pyglet.shapes.Rectangle(573,495,135,135,color=(0,0,0)).draw()
    zlucak1_okraj = pyglet.shapes.Rectangle(813,495,135,135,color=(0,0,0)).draw ()
    player1_obj1_okraj = pyglet.shapes.Rectangle(993,495,135,135,color=(0,0,0)).draw()
    player2_obj1_okraj = pyglet.shapes.Rectangle(1173,495,135,135,color=(0,0,0)).draw()
    fiala1_okraj = pyglet.shapes.Rectangle(1353,495,135,135,color=(0,0,0)).draw()
    modrak_okraj = pyglet.shapes.Rectangle(33,320,135,135,color=(0,0,0)).draw ()
    neco1_okraj = pyglet.shapes.Rectangle(33,320,135,135,color=(0,0,0)).draw ()
    neco2_okraj = pyglet.shapes.Rectangle(573,320,135,135,color=(0,0,0)).draw()
    neco3_okraj = pyglet.shapes.Rectangle(813,320,135,135,color=(0,0,0)).draw ()
    neco4_okraj = pyglet.shapes.Rectangle(1353,320,135,135,color=(0,0,0)).draw()
    neco5 = pyglet.shapes.Rectangle(213,320,135,135,color=(0,0,0)).draw()
    neco6 = pyglet.shapes.Rectangle(393,320,135,135,color=(0,0,0)).draw()
    neco7 = pyglet.shapes.Rectangle(993,320,135,135,color=(0,0,0)).draw()
    neco8 = pyglet.shapes.Rectangle(1173,320,135,135,color=(0,0,0)).draw()

    zlucak = pyglet.shapes.Rectangle(38,500,125,125,color=(255,255,0)).draw ()
    zelenak = pyglet.shapes.Rectangle(218,500,125,125,color=(50,200,50)).draw()
    bila = pyglet.shapes.Rectangle(398,500,125,125,color=(255,255,255)).draw()
    fiala = pyglet.shapes.Rectangle(578,500,125,125,color=(69,30,140)).draw()
    zlucak1 = pyglet.shapes.Rectangle(818,500,125,125,color=(255,255,0)).draw ()
    zelenak1 = pyglet.shapes.Rectangle(998,500,125,125,color=(50,200,50)).draw()
    belasek1 = pyglet.shapes.Rectangle(1178,500,125,125,color=(255,255,255)).draw()
    fiala1 = pyglet.shapes.Rectangle(1358,500,125,125,color=(69,30,140)).draw()
    modra = pyglet.shapes.Rectangle (38,325,125,125,color=(0,0,255)).draw ()
    barva1 = pyglet.shapes.Rectangle(218,325,125,125,color=(50,185,190)).draw()
    ornz = pyglet.shapes.Rectangle(398,325,125,125,color=(255,150,50)).draw()
    ruz = pyglet.shapes.Rectangle(578,325,125,125,color=(255,70,235)).draw()
    modra = pyglet.shapes.Rectangle(818,325,125,125,color=(0,0,255)).draw ()
    barva1 = pyglet.shapes.Rectangle(998,325,125,125,color=(50,185,190)).draw()
    oranz1 = pyglet.shapes.Rectangle(1178,325,125,125,color=(255,150,50)).draw()
    ruz1 = pyglet.shapes.Rectangle(1358,325,125,125,color=(255,70,235)).draw()
    


@window.event
def on_mouse_press(x:int,y:int,tlacitko:int,modifikatory:int):
    global faze_hry
    global p1
    global p2
    if faze_hry == 1:
        if 50 <= x <= 250 and 100 <= y <= 200:
            faze_hry = 1.2
        if 50 <= x <= 250 and 250 <= y <= 350:
            faze_hry = 1.1
        if 50 <= x <= 250 and 400 <= y <= 500:
            pass
        if 50 <= x <= 150 and 700 <= y <= 800:
            pyglet.app.exit()
    if faze_hry == 1.2:
        if 50 <= x <= 250 and 100 <= y <= 200:
            pass
        if 50 <= x <= 250 and 250 <= y <= 350:
            faze_hry = 2
        if 50 <= x <= 250 and 400 <= y <= 500:
            faze_hry = 2.4
        if 50 <= x <= 150 and 700 <= y <= 800:
            faze_hry = 1
    if faze_hry == 1.1:
        if 0 < x < 150 and height-100 < y < height:
            faze_hry = 1
        if 38 <= x <= 163 and 500 <= y <= 625:
            p1 = (255,255,0)
        if 218 <= x <= 343 and 500 <= y <= 625:
            p1 = (50,200,50)
        if 398 <= x <= 523 and 500 <= y <= 625:
            p1 = (255,255,255)
        if 578 <= x <= 703 and 500 <= y <= 625:
            p1 = (69,30,140)
        if 38 <= x <= 163 and 325 <= y <= 450:
            p1 = (0,0,255)
        if 218 <= x <= 343 and 325 <= y <= 450:
            p1 = (50,185,190)
        if 398 <= x <= 523 and 325 <= y <= 450:
            p1 = (255,150,50)
        if 578 <= x <= 703 and 325 <= y <= 450:
            p1 = (255,70,235)
        
        if 818 <= x <= 943 and 500 <= y <= 625:
            p2 = (255,255,0)
        if 998 <= x <= 1123 and 500 <= y <= 625:
            p2 = (50,200,50)
        if 1178 <= x <= 1303 and 500 <= y <= 625:
            p2 = (255,255,255)
        if 1358 <= x <= 1483 and 500 <= y <= 625:
            p2 = (69,30,140)
        if 818 <= x <= 943 and 325 <= y <= 450:
            p2 = (0,0,255)
        if 998 <= x <= 1123 and 325 <= y <= 450:
            p2 = (50,185,190)
        if 1178 <= x <= 1303 and 325 <= y <= 450:
            p2 = (255,150,50)
        if 1358 <= x <= 1483 and 325 <= y <= 450:
            p2 = (255,70,235)




def konec_hry1():
    global faze_hry,napis
    if faze_hry == 2.1:
        if player3_x == player2_x + 25 and player3_y == player2_y + 25 or player3_x + 50 == player2_x +25 and player3_y + 50 == player2_y + 25 or player3_x + 50 == player2_x + 25 and player3_y == player2_y + 25 or player3_x == player2_x + 25 and player3_y + 50 == player2_y + 25 or player3_x == player2_x +25 and player3_y + 25 == player2_y + 25 or player3_x + 25 == player2_x + 25 and player3_y == player2_y + 25 or player3_x + 50 == player2_x + 25 and player3_y + 25 == player2_y + 25 or player3_x + 25 == player2_x + 25 and player3_y + 50 == player2_y + 25:
            window.clear()
            faze_hry = 3
            
    if faze_hry == 2:
        if player3_x == player2_x + 25 and player3_y == player2_y + 25 or player3_x + 50 == player2_x +25 and player3_y + 50 == player2_y + 25 or player3_x + 50 == player2_x + 25 and player3_y == player2_y + 25 or player3_x == player2_x + 25 and player3_y + 50 == player2_y + 25 or player3_x == player2_x +25 and player3_y + 25 == player2_y + 25 or player3_x + 25 == player2_x + 25 and player3_y == player2_y + 25 or player3_x + 50 == player2_x + 25 and player3_y + 25 == player2_y + 25 or player3_x + 25 == player2_x + 25 and player3_y + 50 == player2_y + 25:
            faze_hry = 2.2
    if faze_hry ==2.4:
        if player3_x == player2_x + 25 and player3_y == player2_y + 25 or player3_x + 50 == player2_x +25 and player3_y + 50 == player2_y + 25 or player3_x + 50 == player2_x + 25 and player3_y == player2_y + 25 or player3_x == player2_x + 25 and player3_y + 50 == player2_y + 25 or player3_x == player2_x +25 and player3_y + 25 == player2_y + 25 or player3_x + 25 == player2_x + 25 and player3_y == player2_y + 25 or player3_x + 50 == player2_x + 25 and player3_y + 25 == player2_y + 25 or player3_x + 25 == player2_x + 25 and player3_y + 50 == player2_y + 25:
            faze_hry =3
            

def konec_hry2():
    global faze_hry,napis1
    if faze_hry ==2:
        if player3_x == player1_x + 25 and player3_y == player1_y + 25 or player3_x + 50 == player1_x +25 and player3_y + 50 == player1_y + 25 or player3_x + 50 == player1_x + 25 and player3_y == player1_y + 25 or player3_x == player1_x + 25 and player3_y + 50 == player1_y + 25 or player3_x == player1_x +25 and player3_y + 25 == player1_y + 25 or player3_x + 25 == player1_x + 25 and player3_y == player1_y + 25 or player3_x + 50 == player1_x + 25 and player3_y + 25 == player1_y + 25 or player3_x + 25 == player1_x + 25 and player3_y + 50 == player1_y + 25:
            faze_hry = 2.1
            
    if faze_hry ==2.2:
        if player3_x == player1_x + 25 and player3_y == player1_y + 25 or player3_x + 50 == player1_x +25 and player3_y + 50 == player1_y + 25 or player3_x + 50 == player1_x + 25 and player3_y == player1_y + 25 or player3_x == player1_x + 25 and player3_y + 50 == player1_y + 25 or player3_x == player1_x +25 and player3_y + 25 == player1_y + 25 or player3_x + 25 == player1_x + 25 and player3_y == player1_y + 25 or player3_x + 50 == player1_x + 25 and player3_y + 25 == player1_y + 25 or player3_x + 25 == player1_x + 25 and player3_y + 50 == player1_y + 25:
            window.clear()
            faze_hry = 3
    if faze_hry == 2.4:
        if player3_x == player1_x + 25 and player3_y == player1_y + 25 or player3_x + 50 == player1_x +25 and player3_y + 50 == player1_y + 25 or player3_x + 50 == player1_x + 25 and player3_y == player1_y + 25 or player3_x == player1_x + 25 and player3_y + 50 == player1_y + 25 or player3_x == player1_x +25 and player3_y + 25 == player1_y + 25 or player3_x + 25 == player1_x + 25 and player3_y == player1_y + 25 or player3_x + 50 == player1_x + 25 and player3_y + 25 == player1_y + 25 or player3_x + 25 == player1_x + 25 and player3_y + 50 == player1_y + 25:
            window.clear()
            faze_hry = 3

          
def konec_hry3():
    global faze_hry,score
    if score == 5:
        window.clear()
        faze_hry = 3
        napis2 = pyglet.text.Label("Player 3 is 100% autistic",
                          font_name= "Times New Roman",
                          font_size= 80,
                          color=(255, 0, 0, 255),
                          x = window.width//2, y = window.height//2,
                          anchor_x = "center", anchor_y="center")
        napis2.draw()


n = random.randint(2,59)
m= random.randint(2,30)
o = random.randint(2,59)
p= random.randint(2,30)
q = random.randint(2,59)
r = random.randint(2,30)
def minihra():
    global m,n,score,pepa,o,p,q,r
    pepa = pyglet.shapes.Star(x=n*25,y=m*25,outer_radius = 20, inner_radius=10,num_spikes=5,color=(255,0,0))
    pepa.draw()
    josef =pyglet.shapes.Star(x=o*25,y=p*25,outer_radius = 20, inner_radius=10,num_spikes=5,color=(50,200,50))
    josef.draw()
    karel = pyglet.shapes.Star(x=q*25,y=r*25,outer_radius = 20, inner_radius=10,num_spikes=5,color=(255,255,0))
    karel.draw()
    pyglet.text.Label(f"Score={score}/5",
                      font_name= "Times New Roman",
                          font_size= 40,
                          color=(255, 255, 255),
                          x = window.width/2 , y = window.height-32,
                          anchor_x = "center", anchor_y="center").draw()
    if pepa.x == player2_x + 25 and pepa.y == player2_y + 25 :
        score += 1
        n = random.randint(2,59)
        m= random.randint(2,30)
        pepa.draw()
    if pepa.x == player1_x + 25 and pepa.y == player1_y + 25 :
        score += 1
        n = random.randint(2,59)
        m= random.randint(2,30)
        pepa.draw()
    if josef.x == player2_x + 25 and josef.y == player2_y + 25 :
        score += 1
        o = random.randint(2,59)
        p= random.randint(2,30)
        josef.draw()
    if josef.x == player1_x + 25 and josef.y == player1_y + 25 :
        score += 1
        o = random.randint(2,59)
        p= random.randint(2,30)
        josef.draw()
    if karel.x == player2_x + 25 and karel.y == player2_y + 25 :
        score += 1
        q = random.randint(2,59)
        r= random.randint(2,30)
        karel.draw()
    if karel.x == player1_x + 25 and karel.y == player1_y + 25 :
        score += 1
        q = random.randint(2,59)
        r= random.randint(2,30)
        karel.draw()

time = 0
a1_time = 0
a2_time = 0


def abilita1(dt):
    global a1_time, havlicek1,p1_move,p3_move, player3_x,player3_y
    if p1 == (255,255,0):
        if havlicek1 == 2 or havlicek1 == 3:
            a1_time += 1
            if a1_time > 0 and a1_time < 6:
                p1_move = 50
            if a1_time > 6 and a1_time < 16:
                havlicek1 = 3
            if a1_time == 6:
                p1_move = 25
            if a1_time == 16:
                havlicek1 = 1
                a1_time = 0
  
        c1_text.color = (255,255,0)

    if p1 == (0,0,255):
        if havlicek1 == 2 or havlicek1 == 3:
            a1_time += 1
            if a1_time > 0 and a1_time < 3:
                p3_move = 0
            if a1_time > 3 and a1_time < 16:
                havlicek1 = 3
            if a1_time == 3:
                p3_move = 25
            if a1_time == 16:
                havlicek1 = 1
                a1_time = 0

        c1_text.color = (0,0,255)

    if p1 == (255,255,255):
        if havlicek1 == 2 or havlicek1 == 3:
            a1_time += 1
            if a1_time > 0 and a1_time < 5:
                player1_loko.opacity = 0
                player1_poko.opacity = 0
                player1_u.opacity = 0
            if a1_time > 5 and a1_time < 16:
                havlicek1 = 3
            if a1_time == 5:
                player1_loko.opacity = 255
                player1_poko.opacity = 255
                player1_u.opacity = 255
            if a1_time == 16:
                havlicek1 = 1
                a1_time = 0
  
        c1_text.color = (255,255,255)

    if p1 == (255,150,50):
       if havlicek1 == 2 or havlicek1 == 3:
            a1_time += 1
            if a1_time > 0 and a1_time < 6:
                p3_move = -25
            if a1_time > 6 and a1_time < 16:
                havlicek1 = 3
            if a1_time == 6:
                p3_move = 25
            if a1_time == 16:
                havlicek1 = 1
                a1_time = 0

       c1_text.color = (255,150,50)

    if p1 == (69,30,140):
        if havlicek1 == 2 or havlicek1 == 3:
            a1_time += 1
            if a1_time > 0 and a1_time < 6:
                pass
            if a1_time > 6 and a1_time < 16:
                havlicek1 = 3
            if a1_time == 6:
                pass
            if a1_time == 16:
                havlicek1 = 1
                a1_time = 0

        c1_text.color = (69,30,140)

    if p1 == (255,70,235):
        if havlicek1 == 2 or havlicek1 == 3:
            a1_time += 1
            if a1_time > 0 and a1_time < 6:
                pass
            if a1_time > 6 and a1_time < 16:
                havlicek1 = 3
            if a1_time == 6:
                pass
            if a1_time == 16:
                havlicek1 = 1
                a1_time = 0

        c1_text.color = (255,70,235)

    if p1 == (50,185,190):
        if havlicek1 == 2 or havlicek1 == 3:
            a1_time += 1
            if a1_time > 0 and a1_time < 6:
                if (player3_x >= led1_x and player3_x <= led1_x + 450) and (player3_y >= led1_y and player3_y <= led1_y+ 450):
                    p3_move = 12.5
                else:
                    p3_move = 25
            if a1_time > 6 and a1_time < 16:
                havlicek1 = 3
            if a1_time == 6:
                p3_move = 25
                player3_x = round(player3_x / 25) * 25
                player3_y = round(player3_y / 25) * 25
            if a1_time == 16:
                havlicek1 = 1
                a1_time = 0

        c1_text.color = (50,185,190)

    if p1 == (50,200,50):
        if havlicek1 == 2 or havlicek1 == 3:
            a1_time += 1
            if a1_time > 0 and a1_time < 6:
                pass
            if a1_time > 6 and a1_time < 16:
                havlicek1 = 3
            if a1_time == 6:
                pass
            if a1_time == 16:
                havlicek1 = 1
                a1_time = 0

        c1_text.color = (50,200,50)
    if havlicek1 == 1:
                c1_text.text ="Your ability is ready"
    if havlicek1 == 2:
                c1_text.text = "Your ability is active"
    if havlicek1 == 3:
                c1_text.text = f"You need to wait {17 - a1_time} more seconds "


c1_text = pyglet.text.Label(f"You need to wait {17 - a1_time} more seconds ",
                            font_name= "Times New Roman",
                            font_size= 20,
                            color=(255,255,255),
                            x = 200, y = window.height - 32,
                            anchor_x = "center", anchor_y="center")


def abilita2(dt):
    global a2_time, havlicek2,p2_move,p3_move,player2_loko,player2_poko,player2_u,player2_obj,c2_text, led2_x, led2_y,player3_x,player3_y
    if p2 == (255,255,0):
        if havlicek2 == 2 or havlicek2 == 3:
            a2_time += 1
            if a2_time > 0 and a2_time < 6:
                p2_move = 50
            if a2_time > 6 and a2_time < 16:
                havlicek2 = 3
            if a2_time == 6:
                p2_move = 25
            if a2_time == 16:
                havlicek2 = 1
                a2_time = 0

        c2_text.color = (255,255,0)

    if p2 == (0,0,255):
        if havlicek2 == 2 or havlicek2 == 3:
            a2_time += 1
            if a2_time > 0 and a2_time < 3:
                p3_move = 0
            if a2_time > 3 and a2_time < 16:
                havlicek2 = 3
            if a2_time == 3:
                p3_move = 25
            if a2_time == 16:
                havlicek2 = 1
                a2_time = 0

        c2_text.color = (0,0,255)

    if p2 == (255,255,255):
        if havlicek2 == 2 or havlicek2 == 3:
            a2_time += 1
            if a2_time > 0 and a2_time < 5:
                player2_loko.opacity = 0
                player2_poko.opacity = 0
                player2_u.opacity = 0
            if a2_time > 5 and a2_time < 16:
                havlicek2 = 3
            if a2_time == 5:
                player2_loko.opacity = 255
                player2_poko.opacity = 255
                player2_u.opacity = 255
            if a2_time == 16:
                havlicek2 = 1
                a2_time = 0

        c2_text.color = (255,255,255)

    if p2 == (255,150,50):
            if havlicek2 == 2 or havlicek2 == 3:
                a2_time += 1
                if a2_time > 0 and a2_time < 6:
                    p3_move = -25
                if a2_time > 6 and a2_time < 16:
                    havlicek2 = 3
                if a2_time == 6:
                    p3_move = 25
                if a2_time == 16:
                    havlicek2 = 1
                    a2_time = 0

            c2_text.color = (255,150,50)

    if p2 == (69,30,140):
        if havlicek2 == 2 or havlicek2 == 3:
            a2_time += 1
            if a2_time > 0 and a2_time < 6:
                pass
            if a2_time > 6 and a2_time < 16:
                havlicek2 = 3
            if a2_time == 6:
                p3_move = 25
            if a2_time == 16:
                havlicek2 = 1
                a2_time = 0

        c2_text.color = (69,30,140)
    
    if p2 == (255,70,235):
        if havlicek2 == 2 or havlicek2 == 3:
            a2_time += 1
            if a2_time > 0 and a2_time < 6:
                pass
            if a2_time > 6 and a2_time < 16:
                havlicek2 = 3
            if a2_time == 6:
                p3_move = 25
            if a2_time == 16:
                havlicek2 = 1
                a2_time = 0
        c2_text.color = (255,70,235)
    
    if p2 == (50,185,190):
        if havlicek2 == 2 or havlicek2 == 3:
            a2_time += 1
            if a2_time > 0 and a2_time < 6:
                if (player3_x >= led2_x and player3_x <= led2_x + 450) and (player3_y >= led2_y and player3_y <= led2_y+ 450):
                    p3_move = 12.5
                else:
                    p3_move = 25
            if a2_time > 6 and a2_time < 16:
                havlicek2 = 3
            if a2_time == 6:
                p3_move = 25
                player3_x = round(player3_x / 25) * 25
                player3_y = round(player3_y / 25) * 25
            if a2_time == 16:
                havlicek2 = 1
                a2_time = 0
    if p2 == (50,200,50):
        if havlicek2 == 2 or havlicek2 == 3:
            a2_time += 1
            if a2_time > 0 and a2_time < 6:
                pass
            if a2_time > 6 and a2_time < 16:
                havlicek2 = 3
            if a2_time == 6:
                pass
            if a2_time == 16:
                havlicek2 = 1
                a2_time = 0
            

        c2_text.color = (50,185,190)
    
    if havlicek2 == 1:
                c2_text.text ="Your ability is ready"
    if havlicek2 == 2:
                c2_text.text = "Your ability is active"
    if havlicek2 == 3:
                c2_text.text = f"You need to wait {17 - a2_time} more seconds "
    
    
    
c2_text = pyglet.text.Label(f"You need to wait {17 - a2_time} more seconds ",
                            font_name= "Times New Roman",
                            font_size= 20,
                            color=(p2),
                            x = window.width - 200, y = window.height - 32,
                            anchor_x = "center", anchor_y="center")



    



def pocitadlo(dt):
    global time, cas_text, cas_konec

   
    if faze_hry == 2.4:
        time +=1

    cas_text.text = f"Time = {time} seconds "
    cas_konec.text = f"You survived whole {time} seconds "


pyglet.clock.schedule_interval(pocitadlo, 1)
pyglet.clock.schedule_interval(abilita1, 1)
pyglet.clock.schedule_interval(abilita2, 1)

omrzlina = pyglet.shapes.Rectangle(player3_x,player3_y,50,50,color=(0,0,255))
omrzlina.opacity = 100

led1 = pyglet.shapes.Rectangle(player1_x - 200,player1_y - 200,450,450,color=(0,0,200))
led1.opacity = 100
led2 = pyglet.shapes.Rectangle(player2_x - 200,player2_y - 200,450,450,color=(0,0,200))
led2.opacity = 100
safez1 = pyglet.shapes.Rectangle(player1_x - 100,player1_y - 100,250,250,color=(50,200,50))
safez1.opacity = 100
safez2 = pyglet.shapes.Rectangle(player2_x - 100,player2_y - 100,250,250,color=(50,200,50))
safez2.opacity = 100



cas_text = pyglet.text.Label(f"Time = {time} seconds ",
                            font_name= "Times New Roman",
                            font_size= 20,
                            color=(255, 0, 0, 255),
                            x = 100, y = window.height - 30,
                            anchor_x = "center", anchor_y="center")

cas_konec = pyglet.text.Label(f"You survived whole {time} seconds ",
                                font_name= "Times New Roman",
                                font_size= 80,
                                color=(255, 0, 255, 255),
                                x = window.width//2, y = window.height//2 - 150,
                                anchor_x = "center", anchor_y="center")



#main hra

napis2 = pyglet.text.Label("The End ...",
                            font_name= "Times New Roman",
                            font_size= 80,
                            color=(255, 0, 0, 255),
                            x = window.width//2, y = window.height//2,
                            anchor_x = "center", anchor_y="center")

napis1 = pyglet.text.Label("Player 2 fucked up",
                            font_name= "Times New Roman",
                            font_size= 40,
                            color=(255, 0, 0, 255),
                            x = window.width - 200, y = window.height - 32,
                            anchor_x = "center", anchor_y="center")

napis = pyglet.text.Label("Player 1 fucked up",
                            font_name= "Times New Roman",
                            font_size= 40,
                            color=(255, 0, 0, 255),
                            x = 200, y = window.height - 32,
                            anchor_x = "center", anchor_y="center")
        
player1_obj = pyglet.shapes.Rectangle(player1_x, player1_y, 50, 50, color=p1)
player1_loko = pyglet.shapes.Circle(player1_x + 10, player1_y + 35, 5, color=(0, 0, 0))
player1_poko = pyglet.shapes.Circle(player1_x + 35, player1_y + 35, 5, color=(0, 0, 0))
player1_u = pyglet.shapes.Arc(player1_x + 25, player1_y + 15, 10, color=(0, 0, 0), thickness=2)


player2_obj = pyglet.shapes.Rectangle(player2_x, player2_y, 50, 50, color=p2)
player2_loko = pyglet.shapes.Circle(player2_x + 10, player2_y + 35, 5, color=(0, 0, 0))
player2_poko = pyglet.shapes.Circle(player2_x + 35, player2_y + 35, 5, color=(0, 0, 0))
player2_u = pyglet.shapes.Arc(player2_x + 25, player2_y + 15, 10, color=(0, 0, 0), thickness=2)
            

player2_u = pyglet.shapes.Arc(player2_x, player2_y , 10, color=(0,0,0), thickness= 2)
player3 = pyglet.shapes.Rectangle(player3_x, player3_y, 50, 50, color=(255, 0, 0))
player1_s = player2_x +25, player2_y + 25
player2_s = player1_x + 25, player1_y + 25
pozadi = pyglet.image.load_animation("zare.gif")
pozadi1 = pyglet.sprite.Sprite(pozadi)
pozadi1.scale = 3.2

def panel():
    pyglet.shapes.Rectangle(0,800,window.width,64,color=(0,0,0)).draw()

@window.event
def on_draw():
    global p1,p2
    global player1_x,player1_y,player2_x,player2_y,player3_x,player3_y
    global player2_s,player1_s
    global napis,napis1, omrzlina
    global player1_obj,player2_obj,player3
    global led1,led2, led1_x,led1_y,led2_x,led2_y
    global safez1,safez2, safez1_x,safez1_y,safez2_x,safez2_y
    player1_obj = pyglet.shapes.Rectangle(player1_x,player1_y, 50,50,color=p1)
    if p1 == (255,255,255) and havlicek1 == 2:
        player1_obj.opacity = 0
    if p1 == (255,255,255) and havlicek1 == 3:
        player1_obj.opacity = 255

    player2_obj = pyglet.shapes.Rectangle(player2_x,player2_y,50,50,color=p2)
    if p2 == (255,255,255) and havlicek2 == 2:
        player2_obj.opacity = 0
    if p2 == (255,255,255) and havlicek2 == 3:
        player2_obj.opacity = 255
    player3 = pyglet.shapes.Rectangle(player3_x,player3_y,50,50,color=(255,0,0))
    player1_s = player2_x +25, player2_y + 25
    player2_s = player1_x + 25, player1_y + 25

    player1_obj.x, player1_obj.y = player1_x, player1_y
    player1_loko.x, player1_loko.y = player1_x + 10, player1_y + 35
    player1_poko.x, player1_poko.y = player1_x + 35, player1_y + 35
    player1_u.x, player1_u.y = player1_x + 25, player1_y + 15

        # Aktuální souřadnice pro hráče 2
    player2_obj.x, player2_obj.y = player2_x, player2_y
    player2_loko.x, player2_loko.y = player2_x + 10, player2_y + 35
    player2_poko.x, player2_poko.y = player2_x + 35, player2_y + 35
    player2_u.x, player2_u.y = player2_x + 25, player2_y + 15
    
    player3.x, player3.y = player3_x, player3_y
    omrzlina.x, omrzlina.y = player3_x, player3_y
    if havlicek1 ==1:
        led1.x, led1.y = player1_x - 200, player1_y - 200
        led1_x = led1.x
        led1_y = led1.y
        safez1.x, safez1.y = player1_x - 100, player1_y - 100
        safez1_x = safez1.x
        safez1_y = safez1.y
    if havlicek2 ==1:
        led2.x, led2.y = player2_x - 200, player2_y - 200
        led2_x = led2.x
        led2_y = led2.y
        safez2.x, safez2.y = player2_x - 100, player2_y - 100
        safez2_x = safez2.x
        safez2_y = safez2.y


    if faze_hry == 0:
        uvod()
    if faze_hry == 1:
        lobby()
    if faze_hry == 1.1:
        vyber()
    if faze_hry == 1.2:
        lobby_vyber_miniher()
    if faze_hry == 2:
        window.clear()
        gl.glClearColor(0, 0, 0, 1)
        pozadi1.draw()
        player1_obj.draw()
        player2_obj.draw()
        player1_loko.draw()
        player1_poko.draw()
        player1_u.draw()
        player2_loko.draw()
        player2_poko.draw()
        player2_u.draw()
        player3.draw()
        panel()
        if havlicek1 == 2 and p1 == (0,0,255):
            omrzlina.draw()
        if havlicek2 == 2 and p2 == (0,0,255):
            omrzlina.draw()
        if havlicek1 == 2 and p1 ==(50,185,190):
            led1.draw()
        if havlicek2 == 2 and p2 ==(50,185,190):
            led2.draw()
        if havlicek1 == 2 and p1 ==(50,200,50):
            safez1.draw()
        if havlicek2 == 2 and p2 ==(50,200,50):
            safez2.draw()
        c1_text.draw()
        c2_text.draw()
        minihra()
   
    if faze_hry == 2.1:
        window.clear()
        pozadi1.draw()
        gl.glClearColor(0, 0, 0, 1)
        player2_obj.draw()
        player2_loko.draw()
        player2_poko.draw()
        player2_u.draw()
        player3.draw()
        panel()
        if havlicek2 == 2 and p2 == (0,0,255):
            omrzlina.draw()
        if havlicek2 == 2 and p2 ==(50,185,190):
            led2.draw()
        if havlicek2 == 2 and p2 ==(50,200,50):
            safez2.draw()
        c2_text.draw()
        minihra()
        napis.draw()
       
    if faze_hry == 2.2:
        window.clear()
        pozadi1.draw()
        gl.glClearColor(0, 0, 0, 1)
        player1_obj.draw()
        player1_loko.draw()
        player1_poko.draw()
        player1_u.draw()
        player3.draw()
        panel()
        if havlicek1 == 2 and p1 == (0,0,255):
            omrzlina.draw()
        if havlicek1 == 2 and p1 ==(50,185,190):
            led1.draw()
        if havlicek1 == 2 and p1 ==(50,200,50):
            safez1.draw()
        c1_text.draw()
        minihra()
        napis1.draw()
    
    if faze_hry ==2.4:
        window.clear()
        gl.glClearColor(0, 0, 0, 1)
        player1_obj.draw()
        player2_obj.draw()
        player3.draw()
        cas_text.draw()
        


    if faze_hry ==3:
        window.clear()
        napis2.draw()
        cas_konec.draw()
    
    if faze_hry ==3:
        window.clear()
        napis2.draw()

    
    konec_hry1()
    konec_hry2()
    konec_hry3()
    
window.push_handlers(on_draw)
def on_key_press(symbol, modifikatory):
  global faze_hry,player1_y,player1_x,player2_x,player2_y,player3_y,player3_x,havlicek1,havlicek2, p1_move, a1_time,c1_text, c2_text, p2_move, p3_move
  if faze_hry == 0  and symbol == pyglet.window.key.ENTER:
        faze_hry = 1
  if faze_hry == 2 or 2.4:
    if symbol == pyglet.window.key.LEFT:
          if player2_x > 0:
              player2_x -= p2_move
          else :
                if p2 == (69,30,140)and (havlicek1 ==2 or havlicek2 ==2):
                    player2_x = 1450
                else:
                    player2_x += 25
    elif symbol == pyglet.window.key.RIGHT:
          if player2_x < window.width - 50:
              player2_x  += p2_move
          else :
              if p2 == (69,30,140)and (havlicek1 ==2 or havlicek2 ==2):
                  player2_x =50
              else:
                  player2_x -= 25
    elif symbol == pyglet.window.key.UP:
          if player2_y < window.height - 114:
              player2_y  += p2_move
          else :
              if p2 == (255,70,235)and (havlicek1 ==2 or havlicek2 ==2):
                  player2_y = 0
              else:
                  player2_y -= 25
    elif symbol == pyglet.window.key.DOWN:
          if player2_y > 0:
              player2_y -= p2_move
          else :
            if p2 == (255,70,235)and (havlicek1 ==2 or havlicek2 ==2):
                player2_y = 750
            else:
                player2_y += 25
    elif symbol == pyglet.window.key.A:
          if player1_x > 0:
              player1_x -= p1_move
          else :
            if p1 == (69, 30, 140) and (havlicek1 ==2 or havlicek2 ==2):
                player1_x = 1450
            else :
                player1_x += 25

    elif symbol == pyglet.window.key.D:
          if player1_x < window.width - 50:
              player1_x  += p1_move
          else :
              if p1 == (69, 30, 140) and (havlicek1 ==2 or havlicek2 ==2):
                  player1_x = 50
              else:
                  player1_x -= 25
    elif symbol == pyglet.window.key.W:
          if player1_y < window.height - 114:
              player1_y  += p1_move
          else :
              if p1 == (255,70,235)and (havlicek1 ==2 or havlicek2 ==2):
                  player1_y = 0
              else:
                  player1_y -= 25
    elif symbol == pyglet.window.key.S:
          if player1_y > 0:
              player1_y -= p1_move
          else :
            if p1 == (255,70,235)and (havlicek1 ==2 or havlicek2 ==2):
                player1_y = 750
            else:
                player1_y += 25
    elif symbol == pyglet.window.key.H:
          if player3_x > 0:
              player3_x -= p3_move
          else :
            player3_x += 25
          if havlicek1 == 2 and p1 == (50,200,50):
              if (player3_x +50 > safez1_x and player3_x < safez1_x + 250) and (player3_y +50 > safez1_y and player3_y < safez1_y + 250):
                  player3_x += 2 * p3_move
          if havlicek2 == 2 and p2 == (50,200,50):
              if (player3_x +50 > safez2_x and player3_x < safez2_x + 250) and (player3_y +50 > safez2_y and player3_y < safez2_y + 250):
                  player3_x += 2 * p3_move
         
    elif symbol == pyglet.window.key.K:
          if player3_x < window.width - 50:
              player3_x  += p3_move
          else :
              player3_x -= 25
          if havlicek1 == 2 and p1 == (50,200,50):
              if (player3_x +50 > safez1_x and player3_x < safez1_x + 250) and (player3_y +50 > safez1_y and player3_y < safez1_y + 250):
                  player3_x -= 2* p3_move
          if havlicek2 == 2 and p2 == (50,200,50):
              if (player3_x +50 > safez2_x and player3_x < safez2_x + 250) and (player3_y +50 > safez2_y and player3_y < safez2_y + 250):
                  player3_x -= 2* p3_move
    elif symbol == pyglet.window.key.U:
          if player3_y < window.height - 114:
              player3_y  += p3_move
          else :	
              player3_y -= 25
          if havlicek1 == 2 and p1 == (50,200,50):
              if (player3_x +50 > safez1_x and player3_x < safez1_x + 250) and (player3_y +50 > safez1_y and player3_y < safez1_y + 250):
                  player3_y -= 2* p3_move
          if havlicek2 == 2 and p2 == (50,200,50):
              if (player3_x +50 > safez2_x and player3_x < safez2_x + 250) and (player3_y +50 > safez2_y and player3_y < safez2_y + 250):
                  player3_y -= 2* p3_move 
    elif symbol == pyglet.window.key.J:
          if player3_y > 0:
              player3_y -= p3_move
          else:
              player3_y += 25
          if havlicek1 == 2 and p1 == (50,200,50):
              if (player3_x +50 > safez1_x and player3_x < safez1_x + 250) and (player3_y +50 > safez1_y and player3_y < safez1_y + 250):
                  player3_y +=2* p3_move
          if havlicek2 == 2 and p2 == (50,200,50):
              if (player3_x +50 > safez2_x and player3_x < safez2_x + 250) and (player3_y +50 > safez2_y and player3_y < safez2_y + 250):
                  player3_y +=2* p3_move
                      
    elif symbol == pyglet.window.key.Q:
        if havlicek1 == 1:
            havlicek1 = 2
        if havlicek1 == 2 or havlicek1 == 3:
          pass
    elif symbol == pyglet.window.key.RSHIFT:
        if havlicek2 == 1:
            havlicek2 = 2
        if havlicek2 == 2 or havlicek2 == 3:
            pass

window.push_handlers(on_key_press)

pyglet.app.run()